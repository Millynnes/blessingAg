document.addEventListener('DOMContentLoaded', function() {
    const fortuneForm = document.getElementById('fortuneForm');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultCard = document.getElementById('resultCard');

    fortuneForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Show loading spinner
        loadingSpinner.style.display = 'block';
        resultCard.classList.remove('show');

        const formData = new FormData(fortuneForm);

        try {
            const response = await fetch('/calculate_fortune', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                // Update basic info
                document.getElementById('zodiac').textContent = data.zodiac;
                document.getElementById('element').textContent = data.element;
                document.getElementById('elementDetail').textContent = data.element_detail;
                document.getElementById('compatibleZodiacs').textContent = data.compatible_zodiacs.join('、');
                document.getElementById('luckyNumbers').textContent = data.lucky_numbers.join('、');
                document.getElementById('luckyColors').textContent = data.lucky_colors.join('、');

                // Update monthly fortunes
                const monthlyFortunesContainer = document.getElementById('monthlyFortunes');
                monthlyFortunesContainer.innerHTML = ''; // Clear existing content

                Object.entries(data.monthly_fortunes).forEach(([month, fortune]) => {
                    const monthCard = document.createElement('div');
                    monthCard.className = 'month-card';
                    monthCard.innerHTML = `
                        <h5>${month}</h5>
                        <p>${fortune}</p>
                    `;
                    monthlyFortunesContainer.appendChild(monthCard);
                });

                // Update fortune categories
                document.getElementById('career').textContent = data.career;
                document.getElementById('love').textContent = data.love;
                document.getElementById('health').textContent = data.health;
                document.getElementById('wealth').textContent = data.wealth;

                // Show result with animation
                setTimeout(() => {
                    resultCard.classList.add('show');
                }, 500);
            } else {
                alert(data.error || '发生错误，请重试');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('发生错误，请重试');
        } finally {
            loadingSpinner.style.display = 'none';
        }
    });
});